package com.example.medi_sheba.presentation.LineChart

enum class PointDrawerType {
    None,
    Filled,
    Hollow
}