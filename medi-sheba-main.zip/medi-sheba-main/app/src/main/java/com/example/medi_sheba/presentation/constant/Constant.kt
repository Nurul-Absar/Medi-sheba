package com.example.medi_sheba.presentation.constant

object Constant{
    const val DOCTOR = "Doctor"
    const val PATIENT = "Patient"
    const val NURSE = "Nurse"
}
