package com.example.medi_sheba.model

data class Notification(
    val title: String,
    val description: String,
    val time: String
)
