package com.example.medi_sheba.FirestoreAll

object Constants {
    const val PRODUCTS_COLLECTION= "appointment"
}